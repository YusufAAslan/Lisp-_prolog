 --> How To Compile .lisp file:

 --> Copy All These Steps Into The Terminal
 --> step1:
 --> clisp gpp_interpreter.lisp

 --> when .lisp file is  compiled and runned you have to write on the terminal :

 --> $g++
 --> Then press enter to start terminal interperter
 --> when you start terminal interpreter you have to write at the end "(exit)" in order to indicate the end of source code

 --> "(exit)" is the terminating string on the terminal

 
short workflow of the program:

- after entering $g++  you will be in while loop untill writing (exit) or some syntax error occures
						
- once you enter something like (+ 4 2 ) program will show the syntax resulte whether it is correct or not and the the resulte of the expression or certain task 
						
- ( +  4 2 ) after entering this it calls lexer to tokenize it if true then it calls the parser_generator to evaluate the 
expression and then writes the parse_tree into a file.
