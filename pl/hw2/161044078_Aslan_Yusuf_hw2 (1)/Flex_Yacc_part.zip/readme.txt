--> How To Compile Flex && yacc Code:

--> step1:
--> lex gpp_interpreter.l

--> step2:
--> yacc -d gpp_interpreter.y

--> step3:
--> gcc lex.yy.c y.tab.c -ll -ly

--> step4:
--> ./a.out

--> when yacc compiled and runned you have to write on the terminal :

--> $g++

--> Then press enter to start terminal interperter
--> when you start terminal interpreter you have to write at the end "(exit)" in order to indicate the end of source code

--> "exit" is the terminating string on the terminal
